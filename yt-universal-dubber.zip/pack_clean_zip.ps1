Add-Type -AssemblyName System.IO.Compression
Add-Type -AssemblyName System.IO.Compression.FileSystem

$sourceDir = "C:\Users\ANC\.gemini\antigravity-ide\scratch\yt-universal-dubber"
$zipPath = "C:\Users\ANC\.gemini\antigravity-ide\scratch\cr-remover-app\yt-universal-dubber.zip"
$downloadsZip = "C:\Users\ANC\Downloads\yt-universal-dubber.zip"
$desktopZip = "C:\Users\ANC\Desktop\yt-universal-dubber.zip"

if (Test-Path $zipPath) { Remove-Item $zipPath -Force }

$zip = [System.IO.Compression.ZipFile]::Open($zipPath, [System.IO.Compression.ZipArchiveMode]::Create)

$files = Get-ChildItem -Path $sourceDir -Recurse -File
foreach ($file in $files) {
    if ($file.Name -like "*.ps1" -or $file.Name -like "*.js" -and $file.Name -like "*check*" -or $file.Name -like "*test*") {
        continue
    }
    # Calculate relative path and FORCE forward slash / for cross-platform and Chrome compatibility!
    $relPath = $file.FullName.Substring($sourceDir.Length + 1).Replace('\', '/')
    [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip, $file.FullName, $relPath)
    Write-Host "Added entry with forward slash:" $relPath
}

$zip.Dispose()

Copy-Item $zipPath $downloadsZip -Force
Copy-Item $zipPath $desktopZip -Force

Write-Host "Created valid ZIP with forward slashes:" (Get-Item $zipPath).Length "bytes"
