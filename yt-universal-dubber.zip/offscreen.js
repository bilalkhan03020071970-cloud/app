// =========================================================
// Universal YouTube AI Dubber — Offscreen Audio Engine
// Dedicated HTML5 Audio Player for Native Voice Playback
// =========================================================

let currentAudio = null;

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.target !== 'offscreen') return;

  if (msg.action === 'PLAY_AUDIO') {
    if (currentAudio) {
      currentAudio.pause();
      currentAudio.currentTime = 0;
      currentAudio = null;
    }

    const lang = msg.lang || 'ur';
    const text = msg.text || '';
    const rate = msg.rate || 1.0;

    const url = `https://translate.google.com/translate_tts?ie=UTF-8&q=${encodeURIComponent(text.trim())}&tl=${encodeURIComponent(lang)}&client=tw-ob`;
    const audio = new Audio(url);
    currentAudio = audio;
    audio.playbackRate = rate;

    audio.onended = () => {
      if (currentAudio === audio) currentAudio = null;
      chrome.runtime.sendMessage({ target: 'content', action: 'AUDIO_ENDED' }).catch(() => {});
    };

    audio.onerror = (e) => {
      if (currentAudio === audio) currentAudio = null;
      chrome.runtime.sendMessage({ target: 'content', action: 'AUDIO_ERROR', error: e }).catch(() => {});
    };

    audio.play().then(() => {
      sendResponse({ success: true });
    }).catch(err => {
      console.warn('[Offscreen Dubber] Audio play error:', err);
      sendResponse({ success: false, error: err.message });
    });

    return true; // Keep message channel open for async response
  } else if (msg.action === 'STOP_AUDIO') {
    if (currentAudio) {
      currentAudio.pause();
      currentAudio.currentTime = 0;
      currentAudio = null;
    }
    sendResponse({ success: true });
    return true;
  }
});
