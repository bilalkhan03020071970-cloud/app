# 🎙️ Universal YouTube AI Dubber (Any Language to Any Language)

Real-time, 100% Free AI Voice Dubbing Chrome Extension for YouTube videos.
Translate and dub any video — **English to Urdu/Hindi**, **Urdu to English**, **Arabic**, **Spanish**, **Turkish**, and 20+ languages!

---

## 🚀 How to Install in Chrome / Edge (Step-by-Step)

It takes only **30 seconds** to install:

### Step 1: Open Extensions Page in Your Browser
- In **Google Chrome**, open a new tab and paste:  
  `chrome://extensions/`
- In **Microsoft Edge**, open a new tab and paste:  
  `edge://extensions/`

### Step 2: Turn ON "Developer mode"
- In the top-right corner of the Extensions page, turn the **Developer mode** toggle **ON**.

### Step 3: Click "Load unpacked"
- In the top-left corner, click the **"Load unpacked"** button.
- Browse and select this folder:
  `C:\Users\ANC\.gemini\antigravity-ide\scratch\yt-universal-dubber`
- Click **Select Folder**.

🎉 **Done!** The extension icon will appear in your browser toolbar!

---

## 🎯 How to Use on YouTube

1. Open any YouTube video (e.g., YouTube Creators lecture or podcast in English).
2. You will see a sleek floating pill widget right on the top-right of the video:
   `[🎙️ Dub ON] | [Urdu ▾] | ─`
3. The video's original English audio will automatically duck (lower to 15%), and a clear **Urdu AI voice** will speak the translation sentence-by-sentence in real time!
4. **Want to change language?**  
   Click the dropdown right on the video to switch to **English**, **Hindi**, **Arabic**, **Spanish**, or any other language instantly!
5. **Want full controls?**  
   Click the extension icon in your browser toolbar to adjust:
   - Original Audio Volume (0% Muted to 50%)
   - AI Voice Speed (0.8x to 1.5x)
   - Live Subtitle Banner ON/OFF
   - Select specific installed TTS voice
