$sourceDir = "C:\Users\ANC\.gemini\antigravity-ide\scratch\yt-universal-dubber\*"
$zipInRepo = "C:\Users\ANC\.gemini\antigravity-ide\scratch\cr-remover-app\yt-universal-dubber.zip"
$zipInDownloads = "C:\Users\ANC\Downloads\yt-universal-dubber.zip"
$zipInDesktop = "C:\Users\ANC\Desktop\yt-universal-dubber.zip"

if (Test-Path $zipInRepo) { Remove-Item $zipInRepo -Force }
Compress-Archive -Path $sourceDir -DestinationPath $zipInRepo -Force

Copy-Item $zipInRepo $zipInDownloads -Force
Copy-Item $zipInRepo $zipInDesktop -Force

Write-Host "ZIP created in repo:" (Get-Item $zipInRepo).Length "bytes"
Write-Host "ZIP copied to Downloads:" (Get-Item $zipInDownloads).Length "bytes"
Write-Host "ZIP copied to Desktop:" (Get-Item $zipInDesktop).Length "bytes"
