// =========================================================
// Universal YouTube AI Dubber — Popup Controller
// =========================================================

document.addEventListener('DOMContentLoaded', () => {
  // DOM Elements
  const toggleEnabled   = document.getElementById('toggleEnabled');
  const statusChip      = document.getElementById('statusChip');
  const statusLabel     = document.getElementById('statusLabel');
  const selectSource    = document.getElementById('selectSource');
  const selectTarget    = document.getElementById('selectTarget');
  const selectVoice     = document.getElementById('selectVoice');
  const rangeDucking    = document.getElementById('rangeDucking');
  const valDucking      = document.getElementById('valDucking');
  const rangeRate       = document.getElementById('rangeRate');
  const valRate         = document.getElementById('valRate');
  const checkSubtitles  = document.getElementById('checkSubtitles');
  const btnTestVoice    = document.getElementById('btnTestVoice');

  // Default state
  let state = {
    enabled: true,
    sourceLang: 'auto',
    targetLang: 'ur',
    duckingVolume: 0.0,
    speechRate: 1.05,
    speechPitch: 1.0,
    showSubtitles: true,
    selectedVoiceURI: ''
  };

  let allVoices = [];

  // Sample phrases for voice test
  const SAMPLE_PHRASES = {
    'ur': 'خوش آمدید! یوٹیوب اے آئی ڈبر بالکل صحیح کام کر رہا ہے۔',
    'en': 'Welcome! The YouTube AI Dubber is working perfectly.',
    'hi': 'नमस्ते! यूट्यूब एआई डबर बिल्कुल सही काम कर रहा है।',
    'ar': 'أهلاً بك! نظام الدبلجة بالذكاء الاصطناعي يعمل بشكل ممتاز.',
    'es': '¡Bienvenido! El doblador de YouTube con IA está funcionando perfectamente.',
    'fr': 'Bienvenue ! Le doubleur IA de YouTube fonctionne parfaitement.',
    'de': 'Willkommen! Der YouTube KI-Synchronisierer funktioniert einwandfrei.',
    'tr': 'Hoş geldiniz! YouTube Yapay Zeka Dublajı mükemmel çalışıyor.',
    'ru': 'Добро пожаловать! ИИ-дублирование YouTube работает отлично.'
  };

  // 1. Load Voices & Settings
  function init() {
    loadSettings();
    populateVoices();
    if (window.speechSynthesis.onvoiceschanged !== undefined) {
      window.speechSynthesis.onvoiceschanged = populateVoices;
    }
    checkActiveYouTubeTab();
  }

  function loadSettings() {
    chrome.storage.sync.get(state, (stored) => {
      if (stored) {
        Object.assign(state, stored);
        updateUI();
      }
    });
  }

  function saveSettings() {
    chrome.storage.sync.set(state);
    notifyContentScript();
  }

  function updateUI() {
    toggleEnabled.checked = state.enabled;
    updateStatusChip(state.enabled);

    selectSource.value = state.sourceLang;
    selectTarget.value = state.targetLang;

    rangeDucking.value = Math.round(state.duckingVolume * 100);
    valDucking.textContent = rangeDucking.value == 0 ? '0% (Muted - Pure Dub)' : rangeDucking.value + '%';

    rangeRate.value = state.speechRate;
    valRate.textContent = state.speechRate + 'x';

    checkSubtitles.checked = state.showSubtitles;

    populateVoices();
  }

  function updateStatusChip(enabled) {
    if (enabled) {
      statusChip.classList.remove('off');
      statusLabel.textContent = 'Active & Ready on YouTube';
    } else {
      statusChip.classList.add('off');
      statusLabel.textContent = 'AI Dubbing Paused';
    }
  }

  // 2. Populate Browser TTS Voices
  function populateVoices() {
    allVoices = window.speechSynthesis.getVoices();
    selectVoice.innerHTML = '<option value="">Automatic Best Voice</option>';

    if (!allVoices || allVoices.length === 0) return;

    // Filter voices matching current target language
    const tgt = state.targetLang.toLowerCase();
    const matching = allVoices.filter(v =>
      v.lang.toLowerCase().startsWith(tgt) ||
      (tgt === 'ur' && (v.lang.toLowerCase().includes('ur') || v.name.toLowerCase().includes('urdu') || v.lang.toLowerCase().startsWith('hi')))
    );

    const voiceList = matching.length > 0 ? matching : allVoices;

    voiceList.forEach(v => {
      const opt = document.createElement('option');
      opt.value = v.voiceURI;
      opt.textContent = `${v.name} (${v.lang})`;
      if (v.voiceURI === state.selectedVoiceURI) {
        opt.selected = true;
      }
      selectVoice.appendChild(opt);
    });
  }

  // 3. Notify Content Script on YouTube Tab
  function notifyContentScript() {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs && tabs[0] && tabs[0].url && tabs[0].url.includes('youtube.com')) {
        chrome.tabs.sendMessage(tabs[0].id, {
          action: 'UPDATE_SETTINGS',
          settings: state
        }).catch(() => {});
      }
    });
  }

  function checkActiveYouTubeTab() {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (!tabs || !tabs[0] || !tabs[0].url || !tabs[0].url.includes('youtube.com')) {
        statusLabel.textContent = 'Open a YouTube video to use';
        statusChip.style.borderColor = 'rgba(255, 193, 7, 0.4)';
        statusChip.style.color = '#ffc107';
      }
    });
  }

  // 4. Event Listeners
  toggleEnabled.addEventListener('change', (e) => {
    state.enabled = e.target.checked;
    updateStatusChip(state.enabled);
    saveSettings();
  });

  selectSource.addEventListener('change', (e) => {
    state.sourceLang = e.target.value;
    saveSettings();
  });

  selectTarget.addEventListener('change', (e) => {
    state.targetLang = e.target.value;
    state.selectedVoiceURI = ''; // reset custom voice
    populateVoices();
    saveSettings();
  });

  selectVoice.addEventListener('change', (e) => {
    state.selectedVoiceURI = e.target.value;
    saveSettings();
  });

  rangeDucking.addEventListener('input', (e) => {
    valDucking.textContent = e.target.value == 0 ? '0% (Muted - Pure Dub)' : e.target.value + '%';
    state.duckingVolume = parseInt(e.target.value, 10) / 100;
  });
  rangeDucking.addEventListener('change', saveSettings);

  rangeRate.addEventListener('input', (e) => {
    valRate.textContent = e.target.value + 'x';
    state.speechRate = parseFloat(e.target.value);
  });
  rangeRate.addEventListener('change', saveSettings);

  checkSubtitles.addEventListener('change', (e) => {
    state.showSubtitles = e.target.checked;
    saveSettings();
  });

  // 5. Test Voice Button
  btnTestVoice.addEventListener('click', () => {
    const sampleText = SAMPLE_PHRASES[state.targetLang] || `This is a test of the AI dubbing voice in ${state.targetLang}.`;
    btnTestVoice.disabled = true;
    btnTestVoice.textContent = '🔊 Speaking...';

    const onDone = () => {
      btnTestVoice.disabled = false;
      btnTestVoice.textContent = '▶ Test AI Voice';
    };

    if (chrome.runtime && chrome.runtime.sendMessage) {
      chrome.runtime.sendMessage({
        action: 'PLAY_AUDIO',
        text: sampleText,
        lang: state.targetLang,
        rate: state.speechRate || 1.0
      }, () => {
        setTimeout(onDone, 3500);
      });
    } else {
      playTtsFallback(sampleText, onDone);
    }
  });

  function playTtsFallback(text, onDone) {
    if (!window.speechSynthesis) {
      onDone();
      return;
    }
    const utterance = new SpeechSynthesisUtterance(text);
    if (state.selectedVoiceURI) {
      const selected = allVoices.find(v => v.voiceURI === state.selectedVoiceURI);
      if (selected) utterance.voice = selected;
    } else {
      const match = allVoices.find(v => v.lang.toLowerCase().startsWith(state.targetLang.toLowerCase()));
      if (match) utterance.voice = match;
    }
    utterance.rate = state.speechRate;
    utterance.pitch = state.speechPitch;
    utterance.onend = onDone;
    utterance.onerror = onDone;
    window.speechSynthesis.speak(utterance);
  }

  // Run initialization
  init();
});
