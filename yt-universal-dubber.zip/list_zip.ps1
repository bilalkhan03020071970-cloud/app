
Add-Type -AssemblyName System.IO.Compression.FileSystem
$zip = [System.IO.Compression.ZipFile]::OpenRead('C:/Users/ANC/Downloads/yt-universal-dubber.zip')
foreach ($e in $zip.Entries) {
    Write-Host $e.FullName
}
$zip.Dispose()
