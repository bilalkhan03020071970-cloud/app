// =========================================================
// Universal YouTube AI Dubber — Ultra-Fast Real-Time Engine
// Seamless Phrase Streaming, Audio Queue, and Natural Dubbing
// =========================================================

(function () {
  'use strict';

  if (window.__ytUniversalDubberLoaded) return;
  window.__ytUniversalDubberLoaded = true;

  // Default Configuration
  const state = {
    enabled: true,
    sourceLang: 'auto',
    targetLang: 'ur',        // Default: Urdu
    duckingVolume: 0.12,     // 12% background English audio (bilkul slow, subtle murmur)
    speechRate: 1.08,        // Natural human conversation speed
    speechPitch: 1.0,
    showSubtitles: true,
    isSpeaking: false,
    minimized: false
  };

  // Supported Languages List (Code: Name)
  const LANGUAGES = {
    'ur': 'Urdu (اردو)',
    'en': 'English',
    'hi': 'Hindi (हिन्दी)',
    'ar': 'Arabic (العربية)',
    'es': 'Spanish (Español)',
    'fr': 'French (Français)',
    'de': 'German (Deutsch)',
    'tr': 'Turkish (Türkçe)',
    'ru': 'Russian (Русский)',
    'pt': 'Portuguese (Português)',
    'zh': 'Chinese (中文)',
    'ja': 'Japanese (日本語)',
    'ko': 'Korean (한국어)',
    'it': 'Italian (Italiano)',
    'bn': 'Bengali (বাংলা)',
    'fa': 'Persian (فارسی)'
  };

  // Translation Cache
  const translationCache = new Map();
  const MAX_CACHE_SIZE = 600;

  // Real-time Queue & State Trackers
  const phraseQueue = [];
  let isQueueProcessing = false;
  let currentPlayingAudio = null;
  let captionObserver = null;
  let processedTextHistory = '';
  let flushTimer = null;

  // =========================================================
  // 1. INITIALIZATION & STORAGE
  // =========================================================
  function loadSettings() {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.sync) {
      chrome.storage.sync.get(state, (stored) => {
        if (stored) {
          Object.assign(state, stored);
          updateUIElements();
          applyAudioPolicy();
        }
      });
    }
  }

  function saveSettings() {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.sync) {
      chrome.storage.sync.set(state);
    }
  }

  // =========================================================
  // 2. VIDEO ELEMENT & AUDIO DUCKING (SLOW/SUBTLE BACKGROUND)
  // =========================================================
  function getVideoElement() {
    return document.querySelector('video.html5-main-video') || document.querySelector('video');
  }

  function getPlayerContainer() {
    return document.querySelector('#movie_player') || document.querySelector('.html5-video-player');
  }

  // When Dubbing is ON  -> Original English audio is 12% (very slow / subtle background)
  // When Dubbing is OFF -> Original English audio is 100% (normal)
  function applyAudioPolicy() {
    const video = getVideoElement();
    if (!video) return;

    if (state.enabled) {
      video.muted = false;
      video.volume = state.duckingVolume || 0.12;
    } else {
      video.muted = false;
      video.volume = 1.0;
    }
  }

  // Periodic safety check to ensure background audio stays at 12% while dubbing is active
  setInterval(() => {
    if (state.enabled) {
      const video = getVideoElement();
      if (video && (video.volume > 0.18 || video.muted)) {
        video.muted = false;
        video.volume = state.duckingVolume || 0.12;
      }
      ensureCaptionsEnabled();
    }
  }, 1000);

  // =========================================================
  // 3. CAPTION TRACKING & INSTANT CLAUSE SLICER
  // =========================================================
  function ensureCaptionsEnabled() {
    if (!state.enabled) return;
    const ccBtn = document.querySelector('.ytp-subtitles-button');
    if (ccBtn && ccBtn.getAttribute('aria-pressed') !== 'true') {
      ccBtn.click();
    }
  }

  function initCaptionObserver() {
    if (captionObserver) captionObserver.disconnect();

    const handleCaptionChange = () => {
      if (!state.enabled) return;

      const segments = document.querySelectorAll('.ytp-caption-segment, .caption-visual-line');
      if (!segments || segments.length === 0) return;

      let currentText = Array.from(segments)
        .map(el => el.textContent.trim())
        .filter(t => t.length > 0)
        .join(' ')
        .trim();

      // Clean sound effects: [Music], (Applause)
      currentText = currentText.replace(/\[[^\]]+\]|\([^)]+\)/g, '').trim();
      if (!currentText || currentText === processedTextHistory) return;

      // Extract new words not yet processed
      let newPart = '';
      if (currentText.startsWith(processedTextHistory)) {
        newPart = currentText.slice(processedTextHistory.length).trim();
      } else {
        // Caption window refreshed
        newPart = currentText;
        processedTextHistory = '';
      }

      if (!newPart) return;

      // Check if newPart contains a completed clause (period, comma, question, or 6+ words)
      const clauseMatch = newPart.match(/^(.+?[.,!?])\s*(.*)$/) || (newPart.split(/\s+/).length >= 6 ? [null, newPart, ''] : null);

      if (clauseMatch && clauseMatch[1]) {
        const clause = clauseMatch[1].trim();
        if (clause.length > 1) {
          processedTextHistory += (processedTextHistory ? ' ' : '') + clause;
          clearTimeout(flushTimer);
          queuePhraseForDubbing(clause);
        }
      } else {
        // Schedule a flush timer in case the speaker pauses without punctuation
        clearTimeout(flushTimer);
        flushTimer = setTimeout(() => {
          if (newPart && newPart.length > 2) {
            processedTextHistory += (processedTextHistory ? ' ' : '') + newPart;
            queuePhraseForDubbing(newPart);
          }
        }, 700);
      }
    };

    captionObserver = new MutationObserver(handleCaptionChange);

    const player = getPlayerContainer() || document.body;
    captionObserver.observe(player, { childList: true, subtree: true, characterData: true });
  }

  // =========================================================
  // 4. INSTANT DIRECT TRANSLATION (30-50ms)
  // =========================================================
  async function translateText(text, srcLang, tgtLang) {
    if (!text || text.trim().length === 0) return text;
    if (srcLang === tgtLang) return text;

    const cacheKey = `${srcLang}_${tgtLang}_${text.trim()}`;
    if (translationCache.has(cacheKey)) {
      return translationCache.get(cacheKey);
    }

    try {
      const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=${encodeURIComponent(srcLang)}&tl=${encodeURIComponent(tgtLang)}&dt=t&q=${encodeURIComponent(text.trim())}`;
      const res = await fetch(url);
      if (!res.ok) throw new Error('HTTP ' + res.status);
      const data = await res.json();
      if (Array.isArray(data) && Array.isArray(data[0])) {
        const translated = data[0].map(item => item[0]).join('');
        if (translated) {
          if (translationCache.size > MAX_CACHE_SIZE) {
            const firstKey = translationCache.keys().next().value;
            translationCache.delete(firstKey);
          }
          translationCache.set(cacheKey, translated);
          return translated;
        }
      }
    } catch (_) {}

    return text;
  }

  // =========================================================
  // 5. CONTINUOUS DUBBING AUDIO QUEUE (No Cuts, Real Conversation Flow)
  // =========================================================
  async function queuePhraseForDubbing(englishClause) {
    if (!state.enabled || !englishClause) return;

    // Translate immediately
    const urduClause = await translateText(englishClause, state.sourceLang, state.targetLang);
    if (!urduClause || urduClause.trim().length === 0) return;

    // Add to audio queue
    phraseQueue.push({
      original: englishClause,
      translated: urduClause
    });

    if (!isQueueProcessing) {
      processNextInQueue();
    }
  }

  function processNextInQueue() {
    if (!state.enabled || phraseQueue.length === 0) {
      isQueueProcessing = false;
      state.isSpeaking = false;
      updateStatusDot('ready');
      hideSubtitleBanner();
      return;
    }

    // Drop stale phrases if backlog exceeds 3 items (avoids lagging behind)
    if (phraseQueue.length > 3) {
      phraseQueue.splice(0, phraseQueue.length - 2);
    }

    isQueueProcessing = true;
    state.isSpeaking = true;
    updateStatusDot('speaking');

    const item = phraseQueue.shift();
    showSubtitleBanner(item.original, item.translated);

    // Keep English background volume at 12%
    applyAudioPolicy();

    // Play real human Urdu audio
    const ttsUrl = `https://translate.google.com/translate_tts?ie=UTF-8&q=${encodeURIComponent(item.translated.trim())}&tl=${encodeURIComponent(state.targetLang)}&client=tw-ob`;

    playAudioStream(ttsUrl, item.translated, () => {
      // Natural 60ms breath pause between phrases
      setTimeout(processNextInQueue, 60);
    });
  }

  function playAudioStream(url, fallbackText, onDone) {
    let finished = false;
    const finish = () => {
      if (!finished) {
        finished = true;
        if (currentPlayingAudio === audio) currentPlayingAudio = null;
        onDone();
      }
    };

    const audio = new Audio(url);
    currentPlayingAudio = audio;
    audio.playbackRate = state.speechRate || 1.08;

    audio.onended = finish;
    audio.onerror = () => {
      // Fallback: Web Speech API if internet stream stutters
      playViaWebSpeech(fallbackText, finish);
    };

    const playPromise = audio.play();
    if (playPromise !== undefined) {
      playPromise.catch(() => {
        playViaWebSpeech(fallbackText, finish);
      });
    }
  }

  function playViaWebSpeech(text, callback) {
    if (!window.speechSynthesis || !state.enabled) {
      callback();
      return;
    }

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = state.targetLang === 'ur' ? 'ur-PK' : state.targetLang;
    utterance.rate = state.speechRate || 1.05;

    utterance.onend = callback;
    utterance.onerror = callback;
    window.speechSynthesis.speak(utterance);
  }

  function stopAllSpeech() {
    phraseQueue.length = 0;
    isQueueProcessing = false;
    state.isSpeaking = false;
    if (currentPlayingAudio) {
      currentPlayingAudio.pause();
      currentPlayingAudio = null;
    }
    if (window.speechSynthesis) {
      window.speechSynthesis.cancel();
    }
    updateStatusDot('ready');
    hideSubtitleBanner();
  }

  // =========================================================
  // 6. VIDEO EVENT LISTENERS
  // =========================================================
  function bindVideoEvents() {
    const video = getVideoElement();
    if (!video || video.__ytDubberBound) return;
    video.__ytDubberBound = true;

    video.addEventListener('play', () => {
      ensureCaptionsEnabled();
      applyAudioPolicy();
    });

    video.addEventListener('pause', () => {
      stopAllSpeech();
    });

    video.addEventListener('seeking', () => {
      stopAllSpeech();
      processedTextHistory = '';
    });
  }

  // =========================================================
  // 7. IN-PLAYER FLOATING WIDGET UI
  // =========================================================
  function injectPlayerWidget() {
    if (document.getElementById('yt-dubber-pill')) return;

    const player = getPlayerContainer();
    if (!player) return;

    const pill = document.createElement('div');
    pill.id = 'yt-dubber-pill';
    pill.innerHTML = `
      <span class="yt-dubber-mic" id="ytDubMic">🎙️</span>
      <button class="yt-dubber-btn-toggle" id="ytDubToggle" title="Click to Toggle Dubbing ON/OFF">
        <span>Dub</span> <span id="ytDubStatus">ON</span>
      </button>
      <div class="yt-dubber-dot" id="ytDubDot" title="AI Dubber Status"></div>
      <select class="yt-dubber-select yt-dubber-hide-min" id="ytDubLang">
        ${Object.entries(LANGUAGES).map(([code, name]) =>
          `<option value="${code}" ${code === state.targetLang ? 'selected' : ''}>${name}</option>`
        ).join('')}
      </select>
      <button class="yt-dubber-btn-icon yt-dubber-hide-min" id="ytDubMin" title="Minimize / Expand">─</button>
    `;

    player.appendChild(pill);

    // Live Subtitle Banner inside Player
    const banner = document.createElement('div');
    banner.id = 'yt-dubber-subtitle-banner';
    banner.innerHTML = `<div class="orig" id="ytDubBannerOrig"></div><div class="trans" id="ytDubBannerTrans"></div>`;
    player.appendChild(banner);

    // Toggle button
    const toggleBtn = document.getElementById('ytDubToggle');
    toggleBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      state.enabled = !state.enabled;

      if (!state.enabled) {
        stopAllSpeech();
      } else {
        ensureCaptionsEnabled();
      }

      applyAudioPolicy();
      saveSettings();
      updateUIElements();
    });

    const langSelect = document.getElementById('ytDubLang');
    langSelect.addEventListener('change', (e) => {
      e.stopPropagation();
      state.targetLang = e.target.value;
      stopAllSpeech();
      saveSettings();
    });

    const minBtn = document.getElementById('ytDubMin');
    minBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      state.minimized = !state.minimized;
      pill.classList.toggle('minimized', state.minimized);
      minBtn.textContent = state.minimized ? '▢' : '─';
    });

    updateUIElements();
  }

  function updateUIElements() {
    const pill = document.getElementById('yt-dubber-pill');
    const mic = document.getElementById('ytDubMic');
    const toggleBtn = document.getElementById('ytDubToggle');
    const statusText = document.getElementById('ytDubStatus');
    const langSelect = document.getElementById('ytDubLang');
    const dot = document.getElementById('ytDubDot');

    if (!pill) return;

    if (state.enabled) {
      toggleBtn.classList.remove('off');
      mic.classList.remove('off');
      statusText.textContent = 'ON';
      dot.className = state.isSpeaking ? 'yt-dubber-dot speaking' : 'yt-dubber-dot';
    } else {
      toggleBtn.classList.add('off');
      mic.classList.add('off');
      statusText.textContent = 'OFF';
      dot.className = 'yt-dubber-dot off';
    }

    if (langSelect) langSelect.value = state.targetLang;
  }

  function updateStatusDot(status) {
    const dot = document.getElementById('ytDubDot');
    if (!dot) return;
    if (!state.enabled) {
      dot.className = 'yt-dubber-dot off';
    } else if (status === 'speaking') {
      dot.className = 'yt-dubber-dot speaking';
    } else {
      dot.className = 'yt-dubber-dot';
    }
  }

  function showSubtitleBanner(original, translated) {
    if (!state.showSubtitles) return;
    const banner = document.getElementById('yt-dubber-subtitle-banner');
    const origEl = document.getElementById('ytDubBannerOrig');
    const transEl = document.getElementById('ytDubBannerTrans');
    if (banner && origEl && transEl) {
      origEl.textContent = original;
      transEl.textContent = translated;
      banner.classList.add('visible');
    }
  }

  function hideSubtitleBanner() {
    const banner = document.getElementById('yt-dubber-subtitle-banner');
    if (banner) banner.classList.remove('visible');
  }

  // =========================================================
  // 8. POPUP COMMUNICATION
  // =========================================================
  if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
    chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
      if (msg.action === 'UPDATE_SETTINGS') {
        Object.assign(state, msg.settings);
        updateUIElements();
        applyAudioPolicy();
        if (!state.enabled) {
          stopAllSpeech();
        }
        sendResponse({ success: true });
      } else if (msg.action === 'GET_STATE') {
        sendResponse({ state: state });
      }
      return true;
    });
  }

  // =========================================================
  // 9. BOOTSTRAP & NAVIGATION WATCHER
  // =========================================================
  function boot() {
    loadSettings();
    injectPlayerWidget();
    bindVideoEvents();
    initCaptionObserver();
    ensureCaptionsEnabled();
    applyAudioPolicy();
  }

  boot();

  window.addEventListener('yt-navigate-finish', () => {
    stopAllSpeech();
    processedTextHistory = '';
    setTimeout(boot, 600);
  });
  window.addEventListener('load', boot);

  setInterval(() => {
    if (!document.getElementById('yt-dubber-pill') && getPlayerContainer()) {
      boot();
    }
  }, 2500);

})();
