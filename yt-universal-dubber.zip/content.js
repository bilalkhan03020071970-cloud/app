// =========================================================
// Universal YouTube AI Dubber — Content Script Engine
// Real-time Any-to-Any Language Translation & Voice Dubbing
// =========================================================

(function () {
  'use strict';

  // Prevent multiple injections
  if (window.__ytUniversalDubberLoaded) return;
  window.__ytUniversalDubberLoaded = true;

  // Default Configuration
  const state = {
    enabled: true,
    sourceLang: 'auto',
    targetLang: 'ur',        // Default: Urdu
    duckingVolume: 0.0,      // 0% (Original video completely muted for 100% pure dubbing)
    speechRate: 1.05,        // Slightly brisk for natural dub sync
    speechPitch: 1.0,
    showSubtitles: true,
    selectedVoiceURI: '',
    isSpeaking: false,
    minimized: false,
    originalVideoVolume: 1.0,
    originalVideoMuted: false,
    hasOriginalVolume: false
  };

  // Supported Languages List (Code: Name)
  const LANGUAGES = {
    'ur': 'Urdu (اردو)',
    'en': 'English',
    'hi': 'Hindi (हिन्दी)',
    'ar': 'Arabic (العربية)',
    'es': 'Spanish (Español)',
    'fr': 'French (Français)',
    'de': 'German (Deutsch)',
    'tr': 'Turkish (Türkçe)',
    'ru': 'Russian (Русский)',
    'pt': 'Portuguese (Português)',
    'zh': 'Chinese (中文)',
    'ja': 'Japanese (日本語)',
    'ko': 'Korean (한국어)',
    'it': 'Italian (Italiano)',
    'bn': 'Bengali (বাংলা)',
    'fa': 'Persian (فارسی)'
  };

  // Translation Cache to prevent redundant API calls
  const translationCache = new Map();
  const MAX_CACHE_SIZE = 300;

  // Subtitle Accumulator
  let lastSpokenText = '';
  let pendingTextBuffer = '';
  let debounceTimer = null;
  let captionObserver = null;
  let currentUtterance = null;
  let availableVoices = [];

  // =========================================================
  // 1. INITIALIZATION & STORAGE
  // =========================================================
  function loadSettings() {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.sync) {
      chrome.storage.sync.get(state, (stored) => {
        if (stored) {
          Object.assign(state, stored);
          updateUIElements();
        }
      });
    }
  }

  function saveSettings() {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.sync) {
      chrome.storage.sync.set(state);
    }
  }

  // Load available voices
  function initVoices() {
    availableVoices = window.speechSynthesis.getVoices();
  }
  if (typeof window.speechSynthesis !== 'undefined') {
    initVoices();
    window.speechSynthesis.onvoiceschanged = initVoices;
  }

  // =========================================================
  // 2. VIDEO PLAYER & CAPTIONS SETUP
  // =========================================================
  function getVideoElement() {
    return document.querySelector('video.html5-main-video') || document.querySelector('video');
  }

  function getPlayerContainer() {
    return document.querySelector('#movie_player') || document.querySelector('.html5-video-player');
  }

  // Ensure YouTube closed captions (CC) are enabled so we can read the text
  function ensureCaptionsEnabled() {
    if (!state.enabled) return;
    const ccBtn = document.querySelector('.ytp-subtitles-button');
    if (ccBtn && ccBtn.getAttribute('aria-pressed') !== 'true') {
      ccBtn.click();
    }
  }

  // =========================================================
  // 3. CAPTION OBSERVER & ACCUMULATOR
  // =========================================================
  function initCaptionObserver() {
    if (captionObserver) captionObserver.disconnect();

    captionObserver = new MutationObserver(() => {
      if (!state.enabled) return;

      const segments = document.querySelectorAll('.ytp-caption-segment');
      if (!segments || segments.length === 0) return;

      let fullText = Array.from(segments)
        .map(el => el.textContent.trim())
        .join(' ')
        .trim();

      if (!fullText || fullText === lastSpokenText) return;

      // Clean multiple spaces and non-speech symbols like [Music], (Laughter)
      fullText = fullText.replace(/\[[^\]]+\]|\([^)]+\)/g, '').trim();
      if (!fullText) return;

      // Accumulate text until sentence end or short pause
      pendingTextBuffer = fullText;

      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(() => {
        if (pendingTextBuffer && pendingTextBuffer !== lastSpokenText) {
          const sentence = pendingTextBuffer;
          lastSpokenText = sentence;
          pendingTextBuffer = '';
          processSentence(sentence);
        }
      }, 350); // 350ms pause detects natural sentence break
    });

    // Observe body for player/captions container creation
    const player = getPlayerContainer() || document.body;
    captionObserver.observe(player, { childList: true, subtree: true, characterData: true });
  }

  // =========================================================
  // 4. FREE TRANSLATION ENGINE (Google Translate Web API)
  // =========================================================
  async function translateText(text, srcLang, tgtLang) {
    if (!text || text.trim().length === 0) return text;
    if (srcLang === tgtLang) return text;

    const cacheKey = `${srcLang}_${tgtLang}_${text}`;
    if (translationCache.has(cacheKey)) {
      return translationCache.get(cacheKey);
    }

    try {
      const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=${srcLang}&tl=${tgtLang}&dt=t&q=${encodeURIComponent(text)}`;
      const res = await fetch(url);
      if (!res.ok) throw new Error('Translation HTTP ' + res.status);

      const data = await res.json();
      let translated = '';
      if (Array.isArray(data) && Array.isArray(data[0])) {
        translated = data[0].map(item => item[0]).join('');
      }

      if (translated) {
        if (translationCache.size > MAX_CACHE_SIZE) {
          const firstKey = translationCache.keys().next().value;
          translationCache.delete(firstKey);
        }
        translationCache.set(cacheKey, translated);
        return translated;
      }
      return text;
    } catch (err) {
      console.warn('[YT AI Dubber] Translation fallback:', err);
      return text;
    }
  }

  // =========================================================
  // 5. TEXT-TO-SPEECH (TTS) & AUDIO DUCKING / MUTING
  // =========================================================
  function findBestVoice(langCode) {
    if (!availableVoices || availableVoices.length === 0) {
      availableVoices = window.speechSynthesis.getVoices();
    }

    // 1. User selected specific voice
    if (state.selectedVoiceURI) {
      const userVoice = availableVoices.find(v => v.voiceURI === state.selectedVoiceURI);
      if (userVoice) return userVoice;
    }

    // 2. Exact match (e.g. ur-PK, hi-IN, en-US)
    let match = availableVoices.find(v => v.lang.toLowerCase().startsWith(langCode.toLowerCase()));

    // 3. Special Urdu voice search (Urdu is often named 'Urdu', 'Google اردو', 'Microsoft Asad')
    if (!match && langCode === 'ur') {
      match = availableVoices.find(v =>
        v.lang.toLowerCase().includes('ur') ||
        v.name.toLowerCase().includes('urdu') ||
        v.name.toLowerCase().includes('asad')
      );
    }

    // 4. Special Hindi fallback for Urdu if no native Urdu voice installed on system
    if (!match && langCode === 'ur') {
      match = availableVoices.find(v => v.lang.toLowerCase().startsWith('hi'));
    }

    return match || null;
  }

  function applyAudioDucking() {
    const video = getVideoElement();
    if (!video) return;

    if (state.enabled) {
      // Capture original volume if not already stored
      if (!state.hasOriginalVolume) {
        state.originalVideoVolume = video.volume > 0 ? video.volume : 1.0;
        state.originalVideoMuted = video.muted;
        state.hasOriginalVolume = true;
      }

      // If duckingVolume is 0 (default), completely mute original video so only AI dub is heard
      if (state.duckingVolume === 0) {
        video.muted = true;
      } else {
        if (state.isSpeaking) {
          video.muted = false;
          video.volume = Math.min(state.duckingVolume, state.originalVideoVolume);
        } else {
          video.muted = false;
          video.volume = state.originalVideoVolume;
        }
      }
    } else {
      // Extension is OFF — restore original video sound completely
      if (state.hasOriginalVolume) {
        video.muted = state.originalVideoMuted;
        video.volume = state.originalVideoVolume > 0 ? state.originalVideoVolume : 1.0;
        state.hasOriginalVolume = false;
      } else {
        video.muted = false;
      }
    }
  }

  function startAudioDucking() {
    state.isSpeaking = true;
    updateStatusDot('speaking');
    applyAudioDucking();
  }

  function stopAudioDucking() {
    state.isSpeaking = false;
    updateStatusDot('ready');
    applyAudioDucking();
  }

  async function processSentence(originalSentence) {
    if (!state.enabled || !originalSentence) return;

    const translatedSentence = await translateText(originalSentence, state.sourceLang, state.targetLang);
    showSubtitleBanner(originalSentence, translatedSentence);
    speakSentence(translatedSentence);
  }

  function speakSentence(text) {
    if (!window.speechSynthesis || !state.enabled) return;

    // Cancel any previous utterance to avoid overlapping speech lag
    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    const voice = findBestVoice(state.targetLang);
    if (voice) {
      utterance.voice = voice;
      utterance.lang = voice.lang;
    } else {
      utterance.lang = state.targetLang;
    }

    utterance.rate = state.speechRate;
    utterance.pitch = state.speechPitch;

    utterance.onstart = () => {
      startAudioDucking();
    };

    utterance.onend = () => {
      stopAudioDucking();
      hideSubtitleBanner();
    };

    utterance.onerror = (e) => {
      if (e.error !== 'interrupted' && e.error !== 'canceled') {
        console.warn('[YT AI Dubber] Speech error:', e);
      }
      stopAudioDucking();
      hideSubtitleBanner();
    };

    currentUtterance = utterance;
    window.speechSynthesis.speak(utterance);
  }

  // Sync with video play/pause/seek
  function bindVideoEvents() {
    const video = getVideoElement();
    if (!video || video.__ytDubberBound) return;
    video.__ytDubberBound = true;

    video.addEventListener('pause', () => {
      if (window.speechSynthesis) window.speechSynthesis.cancel();
      stopAudioDucking();
      hideSubtitleBanner();
    });

    video.addEventListener('seeking', () => {
      if (window.speechSynthesis) window.speechSynthesis.cancel();
      stopAudioDucking();
      hideSubtitleBanner();
      lastSpokenText = '';
      pendingTextBuffer = '';
    });

    video.addEventListener('play', () => {
      ensureCaptionsEnabled();
      applyAudioDucking();
    });

    // Guard against YouTube player unmuting original audio while pure dubbing is active
    video.addEventListener('volumechange', () => {
      if (state.enabled && state.duckingVolume === 0 && !video.muted) {
        if (!video.__mutingLock) {
          video.__mutingLock = true;
          video.muted = true;
          setTimeout(() => { video.__mutingLock = false; }, 60);
        }
      }
    });
  }

  // =========================================================
  // 6. IN-PLAYER FLOATING WIDGET UI
  // =========================================================
  function injectPlayerWidget() {
    if (document.getElementById('yt-dubber-pill')) return;

    const player = getPlayerContainer();
    if (!player) return;

    const pill = document.createElement('div');
    pill.id = 'yt-dubber-pill';
    pill.innerHTML = `
      <span class="yt-dubber-mic" id="ytDubMic">🎙️</span>
      <button class="yt-dubber-btn-toggle" id="ytDubToggle">
        <span>Dub</span> <span id="ytDubStatus">ON</span>
      </button>
      <div class="yt-dubber-dot" id="ytDubDot" title="AI Dubber Ready"></div>
      <select class="yt-dubber-select yt-dubber-hide-min" id="ytDubLang">
        ${Object.entries(LANGUAGES).map(([code, name]) =>
          `<option value="${code}" ${code === state.targetLang ? 'selected' : ''}>${name}</option>`
        ).join('')}
      </select>
      <button class="yt-dubber-btn-icon yt-dubber-hide-min" id="ytDubMin" title="Minimize / Expand">─</button>
    `;

    player.appendChild(pill);

    // Live Subtitle Banner inside Player
    const banner = document.createElement('div');
    banner.id = 'yt-dubber-subtitle-banner';
    banner.innerHTML = `<div class="orig" id="ytDubBannerOrig"></div><div class="trans" id="ytDubBannerTrans"></div>`;
    player.appendChild(banner);

    // Event Listeners for Pill Controls
    const toggleBtn = document.getElementById('ytDubToggle');
    toggleBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      state.enabled = !state.enabled;
      if (!state.enabled && window.speechSynthesis) {
        window.speechSynthesis.cancel();
        hideSubtitleBanner();
      } else {
        ensureCaptionsEnabled();
      }
      applyAudioDucking();
      saveSettings();
      updateUIElements();
    });

    const langSelect = document.getElementById('ytDubLang');
    langSelect.addEventListener('change', (e) => {
      e.stopPropagation();
      state.targetLang = e.target.value;
      if (window.speechSynthesis) window.speechSynthesis.cancel();
      stopAudioDucking();
      saveSettings();
    });

    const minBtn = document.getElementById('ytDubMin');
    minBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      state.minimized = !state.minimized;
      pill.classList.toggle('minimized', state.minimized);
      minBtn.textContent = state.minimized ? '▢' : '─';
    });

    updateUIElements();
  }

  function updateUIElements() {
    const pill = document.getElementById('yt-dubber-pill');
    const mic = document.getElementById('ytDubMic');
    const toggleBtn = document.getElementById('ytDubToggle');
    const statusText = document.getElementById('ytDubStatus');
    const langSelect = document.getElementById('ytDubLang');
    const dot = document.getElementById('ytDubDot');

    if (!pill) return;

    if (state.enabled) {
      toggleBtn.classList.remove('off');
      mic.classList.remove('off');
      statusText.textContent = 'ON';
      dot.className = 'yt-dubber-dot';
    } else {
      toggleBtn.classList.add('off');
      mic.classList.add('off');
      statusText.textContent = 'OFF';
      dot.className = 'yt-dubber-dot off';
    }

    if (langSelect) langSelect.value = state.targetLang;
  }

  function updateStatusDot(status) {
    const dot = document.getElementById('ytDubDot');
    if (!dot) return;
    if (!state.enabled) {
      dot.className = 'yt-dubber-dot off';
    } else if (status === 'speaking') {
      dot.className = 'yt-dubber-dot speaking';
    } else {
      dot.className = 'yt-dubber-dot';
    }
  }

  function showSubtitleBanner(original, translated) {
    if (!state.showSubtitles) return;
    const banner = document.getElementById('yt-dubber-subtitle-banner');
    const origEl = document.getElementById('ytDubBannerOrig');
    const transEl = document.getElementById('ytDubBannerTrans');
    if (banner && origEl && transEl) {
      origEl.textContent = original;
      transEl.textContent = translated;
      banner.classList.add('visible');
    }
  }

  function hideSubtitleBanner() {
    const banner = document.getElementById('yt-dubber-subtitle-banner');
    if (banner) banner.classList.remove('visible');
  }

  // =========================================================
  // 7. LISTEN FOR EXTENSION POPUP MESSAGES
  // =========================================================
  if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
    chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
      if (msg.action === 'UPDATE_SETTINGS') {
        Object.assign(state, msg.settings);
        updateUIElements();
        if (!state.enabled && window.speechSynthesis) {
          window.speechSynthesis.cancel();
          hideSubtitleBanner();
        }
        applyAudioDucking();
        sendResponse({ success: true });
      } else if (msg.action === 'GET_STATE') {
        sendResponse({ state: state, voices: availableVoices.map(v => ({ name: v.name, lang: v.lang, uri: v.voiceURI })) });
      }
      return true;
    });
  }

  // =========================================================
  // 8. WATCH FOR YOUTUBE SPA PAGE NAVIGATION (yt-navigate-finish)
  // =========================================================
  function boot() {
    loadSettings();
    injectPlayerWidget();
    bindVideoEvents();
    initCaptionObserver();
    ensureCaptionsEnabled();
    applyAudioDucking();
  }

  // Run on initial load
  boot();

  // YouTube is a Single Page Application (SPA), listen for navigation events
  window.addEventListener('yt-navigate-finish', () => {
    setTimeout(boot, 800);
  });
  window.addEventListener('load', boot);

  // Periodic heartbeat to re-attach UI if YouTube re-renders the player
  setInterval(() => {
    if (!document.getElementById('yt-dubber-pill') && getPlayerContainer()) {
      boot();
    }
  }, 2500);

})();
