// =========================================================
// Universal YouTube AI Dubber — Content Script Engine
// Real-time Any-to-Any Language Translation & Voice Dubbing
// =========================================================

(function () {
  'use strict';

  // Prevent multiple injections
  if (window.__ytUniversalDubberLoaded) return;
  window.__ytUniversalDubberLoaded = true;

  // Default Configuration
  const state = {
    enabled: true,
    sourceLang: 'auto',
    targetLang: 'ur',        // Default: Urdu
    duckingVolume: 0.0,
    speechRate: 1.0,         // Natural speaking pace
    speechPitch: 1.0,
    showSubtitles: true,
    selectedVoiceURI: '',
    isSpeaking: false,
    minimized: false
  };

  // Supported Languages List (Code: Name)
  const LANGUAGES = {
    'ur': 'Urdu (اردو)',
    'en': 'English',
    'hi': 'Hindi (हिन्दी)',
    'ar': 'Arabic (العربية)',
    'es': 'Spanish (Español)',
    'fr': 'French (Français)',
    'de': 'German (Deutsch)',
    'tr': 'Turkish (Türkçe)',
    'ru': 'Russian (Русский)',
    'pt': 'Portuguese (Português)',
    'zh': 'Chinese (中文)',
    'ja': 'Japanese (日本語)',
    'ko': 'Korean (한국어)',
    'it': 'Italian (Italiano)',
    'bn': 'Bengali (বাংলা)',
    'fa': 'Persian (فارسی)'
  };

  // Translation Cache
  const translationCache = new Map();
  const MAX_CACHE_SIZE = 500;

  // Subtitle Accumulator
  let lastSpokenText = '';
  let pendingTextBuffer = '';
  let debounceTimer = null;
  let captionObserver = null;
  let availableVoices = [];

  // =========================================================
  // 1. INITIALIZATION & STORAGE
  // =========================================================
  function loadSettings() {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.sync) {
      chrome.storage.sync.get(state, (stored) => {
        if (stored) {
          Object.assign(state, stored);
          updateUIElements();
          updateVideoMute();
        }
      });
    }
  }

  function saveSettings() {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.sync) {
      chrome.storage.sync.set(state);
    }
  }

  function initVoices() {
    if (typeof window.speechSynthesis !== 'undefined') {
      availableVoices = window.speechSynthesis.getVoices();
    }
  }
  if (typeof window.speechSynthesis !== 'undefined') {
    initVoices();
    window.speechSynthesis.onvoiceschanged = initVoices;
  }

  // =========================================================
  // 2. VIDEO ELEMENT & AUDIO MUTING POLICY
  // =========================================================
  function getVideoElement() {
    return document.querySelector('video.html5-main-video') || document.querySelector('video');
  }

  function getPlayerContainer() {
    return document.querySelector('#movie_player') || document.querySelector('.html5-video-player');
  }

  // Pure Dubbing Rule:
  // When Dubbing is ON  -> Original video is 100% MUTED (Silent)
  // When Dubbing is OFF -> Original video is UNMUTED (Sound restored)
  function updateVideoMute() {
    const video = getVideoElement();
    if (!video) return;

    if (state.enabled) {
      if (!video.muted) {
        video.muted = true;
      }
    } else {
      if (video.muted) {
        video.muted = false;
        if (video.volume === 0) video.volume = 1.0;
      }
    }
  }

  // Periodic safety check to ensure original video stays muted while dubbing is active
  setInterval(() => {
    if (state.enabled) {
      updateVideoMute();
      ensureCaptionsEnabled();
    }
  }, 1000);

  // =========================================================
  // 3. CAPTION OBSERVER & ACCUMULATOR
  // =========================================================
  function ensureCaptionsEnabled() {
    if (!state.enabled) return;
    const ccBtn = document.querySelector('.ytp-subtitles-button');
    if (ccBtn && ccBtn.getAttribute('aria-pressed') !== 'true') {
      ccBtn.click();
    }
  }

  function initCaptionObserver() {
    if (captionObserver) captionObserver.disconnect();

    captionObserver = new MutationObserver(() => {
      if (!state.enabled) return;

      const segments = document.querySelectorAll('.ytp-caption-segment');
      if (!segments || segments.length === 0) return;

      let fullText = Array.from(segments)
        .map(el => el.textContent.trim())
        .filter(t => t.length > 0)
        .join(' ')
        .trim();

      if (!fullText || fullText === lastSpokenText) return;

      // Clean multiple spaces and non-speech symbols like [Music], (Laughter)
      fullText = fullText.replace(/\[[^\]]+\]|\([^)]+\)/g, '').trim();
      if (!fullText || fullText.length < 2) return;

      pendingTextBuffer = fullText;

      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(() => {
        if (pendingTextBuffer && pendingTextBuffer !== lastSpokenText) {
          const sentence = pendingTextBuffer;
          lastSpokenText = sentence;
          pendingTextBuffer = '';
          processSentence(sentence);
        }
      }, 350); // 350ms pause detects sentence break
    });

    const player = getPlayerContainer() || document.body;
    captionObserver.observe(player, { childList: true, subtree: true, characterData: true });
  }

  // =========================================================
  // 4. FREE TRANSLATION ENGINE (Google Web API with CORS support)
  // =========================================================
  async function translateText(text, srcLang, tgtLang) {
    if (!text || text.trim().length === 0) return text;
    if (srcLang === tgtLang) return text;

    const cacheKey = `${srcLang}_${tgtLang}_${text.trim()}`;
    if (translationCache.has(cacheKey)) {
      return translationCache.get(cacheKey);
    }

    try {
      const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=${encodeURIComponent(srcLang)}&tl=${encodeURIComponent(tgtLang)}&dt=t&q=${encodeURIComponent(text.trim())}`;
      const res = await fetch(url);
      if (!res.ok) throw new Error('Translation HTTP ' + res.status);

      const data = await res.json();
      let translated = '';
      if (Array.isArray(data) && Array.isArray(data[0])) {
        translated = data[0].map(item => item[0]).join('');
      }

      if (translated) {
        if (translationCache.size > MAX_CACHE_SIZE) {
          const firstKey = translationCache.keys().next().value;
          translationCache.delete(firstKey);
        }
        translationCache.set(cacheKey, translated);
        return translated;
      }
      return text;
    } catch (err) {
      console.warn('[YT AI Dubber] Translation fallback:', err);
      return text;
    }
  }

  // =========================================================
  // 5. TEXT-TO-SPEECH (TTS) & VOICE DISPATCHER
  // =========================================================
  function findBestVoice(langCode) {
    if (!availableVoices || availableVoices.length === 0) {
      availableVoices = window.speechSynthesis.getVoices();
    }

    // 1. User selected specific voice
    if (state.selectedVoiceURI) {
      const userVoice = availableVoices.find(v => v.voiceURI === state.selectedVoiceURI);
      if (userVoice) return userVoice;
    }

    // 2. Exact match (e.g. ur-PK, hi-IN, en-US)
    let match = availableVoices.find(v => v.lang.toLowerCase().startsWith(langCode.toLowerCase()));

    // 3. Special Urdu voice search
    if (!match && langCode === 'ur') {
      match = availableVoices.find(v =>
        v.lang.toLowerCase().includes('ur') ||
        v.name.toLowerCase().includes('urdu') ||
        v.name.toLowerCase().includes('asad') ||
        v.name.toLowerCase().includes('uzma')
      );
    }

    // 4. Special Hindi fallback for Urdu (reads Urdu phonetically with clear South Asian accent)
    if (!match && langCode === 'ur') {
      match = availableVoices.find(v =>
        v.lang.toLowerCase().startsWith('hi') ||
        v.name.toLowerCase().includes('hindi') ||
        v.name.toLowerCase().includes('swara')
      );
    }

    return match || null;
  }

  async function processSentence(originalSentence) {
    if (!state.enabled || !originalSentence) return;

    // Keep video muted while dubbing
    const video = getVideoElement();
    if (video && !video.muted) video.muted = true;

    const translatedSentence = await translateText(originalSentence, state.sourceLang, state.targetLang);
    showSubtitleBanner(originalSentence, translatedSentence);
    speakSentence(translatedSentence);
  }

  function speakSentence(text) {
    if (!window.speechSynthesis || !state.enabled || !text || text.trim().length === 0) return;

    // Cancel any previous utterance to avoid overlapping speech lag
    window.speechSynthesis.cancel();

    // Ensure original video is muted
    const video = getVideoElement();
    if (video && !video.muted) video.muted = true;

    const utterance = new SpeechSynthesisUtterance(text);
    const voice = findBestVoice(state.targetLang);
    if (voice) {
      utterance.voice = voice;
      utterance.lang = voice.lang;
    } else {
      utterance.lang = state.targetLang === 'ur' ? 'ur-PK' : state.targetLang;
    }

    utterance.rate = state.speechRate || 1.0;
    utterance.pitch = state.speechPitch || 1.0;

    utterance.onstart = () => {
      state.isSpeaking = true;
      updateStatusDot('speaking');
      const v = getVideoElement();
      if (v && !v.muted) v.muted = true;
    };

    utterance.onend = () => {
      state.isSpeaking = false;
      updateStatusDot('ready');
      hideSubtitleBanner();
      // Keep original video muted while enabled!
    };

    utterance.onerror = () => {
      state.isSpeaking = false;
      updateStatusDot('ready');
      hideSubtitleBanner();
    };

    window.speechSynthesis.speak(utterance);
  }

  // Sync with video play/pause/seek
  function bindVideoEvents() {
    const video = getVideoElement();
    if (!video || video.__ytDubberBound) return;
    video.__ytDubberBound = true;

    video.addEventListener('play', () => {
      ensureCaptionsEnabled();
      updateVideoMute();
    });

    video.addEventListener('pause', () => {
      if (window.speechSynthesis) window.speechSynthesis.cancel();
      hideSubtitleBanner();
    });

    video.addEventListener('seeking', () => {
      if (window.speechSynthesis) window.speechSynthesis.cancel();
      hideSubtitleBanner();
      lastSpokenText = '';
      pendingTextBuffer = '';
    });

    video.addEventListener('volumechange', () => {
      if (state.enabled && !video.muted) {
        video.muted = true;
      }
    });
  }

  // =========================================================
  // 6. IN-PLAYER FLOATING WIDGET UI
  // =========================================================
  function injectPlayerWidget() {
    if (document.getElementById('yt-dubber-pill')) return;

    const player = getPlayerContainer();
    if (!player) return;

    const pill = document.createElement('div');
    pill.id = 'yt-dubber-pill';
    pill.innerHTML = `
      <span class="yt-dubber-mic" id="ytDubMic">🎙️</span>
      <button class="yt-dubber-btn-toggle" id="ytDubToggle" title="Click to Toggle Dubbing ON/OFF">
        <span>Dub</span> <span id="ytDubStatus">ON</span>
      </button>
      <div class="yt-dubber-dot" id="ytDubDot" title="AI Dubber Status"></div>
      <select class="yt-dubber-select yt-dubber-hide-min" id="ytDubLang">
        ${Object.entries(LANGUAGES).map(([code, name]) =>
          `<option value="${code}" ${code === state.targetLang ? 'selected' : ''}>${name}</option>`
        ).join('')}
      </select>
      <button class="yt-dubber-btn-icon yt-dubber-hide-min" id="ytDubMin" title="Minimize / Expand">─</button>
    `;

    player.appendChild(pill);

    // Live Subtitle Banner inside Player
    const banner = document.createElement('div');
    banner.id = 'yt-dubber-subtitle-banner';
    banner.innerHTML = `<div class="orig" id="ytDubBannerOrig"></div><div class="trans" id="ytDubBannerTrans"></div>`;
    player.appendChild(banner);

    // Toggle button event
    const toggleBtn = document.getElementById('ytDubToggle');
    toggleBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      state.enabled = !state.enabled;

      const video = getVideoElement();
      if (state.enabled) {
        if (video) video.muted = true;
        ensureCaptionsEnabled();
      } else {
        if (video) {
          video.muted = false;
          if (video.volume === 0) video.volume = 1.0;
        }
        if (window.speechSynthesis) window.speechSynthesis.cancel();
        hideSubtitleBanner();
      }

      saveSettings();
      updateUIElements();
    });

    const langSelect = document.getElementById('ytDubLang');
    langSelect.addEventListener('change', (e) => {
      e.stopPropagation();
      state.targetLang = e.target.value;
      if (window.speechSynthesis) window.speechSynthesis.cancel();
      saveSettings();
    });

    const minBtn = document.getElementById('ytDubMin');
    minBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      state.minimized = !state.minimized;
      pill.classList.toggle('minimized', state.minimized);
      minBtn.textContent = state.minimized ? '▢' : '─';
    });

    updateUIElements();
  }

  function updateUIElements() {
    const pill = document.getElementById('yt-dubber-pill');
    const mic = document.getElementById('ytDubMic');
    const toggleBtn = document.getElementById('ytDubToggle');
    const statusText = document.getElementById('ytDubStatus');
    const langSelect = document.getElementById('ytDubLang');
    const dot = document.getElementById('ytDubDot');

    if (!pill) return;

    if (state.enabled) {
      toggleBtn.classList.remove('off');
      mic.classList.remove('off');
      statusText.textContent = 'ON';
      dot.className = state.isSpeaking ? 'yt-dubber-dot speaking' : 'yt-dubber-dot';
    } else {
      toggleBtn.classList.add('off');
      mic.classList.add('off');
      statusText.textContent = 'OFF';
      dot.className = 'yt-dubber-dot off';
    }

    if (langSelect) langSelect.value = state.targetLang;
  }

  function updateStatusDot(status) {
    const dot = document.getElementById('ytDubDot');
    if (!dot) return;
    if (!state.enabled) {
      dot.className = 'yt-dubber-dot off';
    } else if (status === 'speaking') {
      dot.className = 'yt-dubber-dot speaking';
    } else {
      dot.className = 'yt-dubber-dot';
    }
  }

  function showSubtitleBanner(original, translated) {
    if (!state.showSubtitles) return;
    const banner = document.getElementById('yt-dubber-subtitle-banner');
    const origEl = document.getElementById('ytDubBannerOrig');
    const transEl = document.getElementById('ytDubBannerTrans');
    if (banner && origEl && transEl) {
      origEl.textContent = original;
      transEl.textContent = translated;
      banner.classList.add('visible');
    }
  }

  function hideSubtitleBanner() {
    const banner = document.getElementById('yt-dubber-subtitle-banner');
    if (banner) banner.classList.remove('visible');
  }

  // =========================================================
  // 7. LISTEN FOR EXTENSION POPUP MESSAGES
  // =========================================================
  if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
    chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
      if (msg.action === 'UPDATE_SETTINGS') {
        Object.assign(state, msg.settings);
        updateUIElements();
        updateVideoMute();
        if (!state.enabled && window.speechSynthesis) {
          window.speechSynthesis.cancel();
          hideSubtitleBanner();
        }
        sendResponse({ success: true });
      } else if (msg.action === 'GET_STATE') {
        sendResponse({
          state: state,
          voices: availableVoices.map(v => ({ name: v.name, lang: v.lang, uri: v.voiceURI }))
        });
      }
      return true;
    });
  }

  // =========================================================
  // 8. WATCH FOR YOUTUBE SPA PAGE NAVIGATION (yt-navigate-finish)
  // =========================================================
  function boot() {
    loadSettings();
    injectPlayerWidget();
    bindVideoEvents();
    initCaptionObserver();
    ensureCaptionsEnabled();
    updateVideoMute();
  }

  boot();

  window.addEventListener('yt-navigate-finish', () => {
    setTimeout(boot, 800);
  });
  window.addEventListener('load', boot);

  // Periodic heartbeat to re-attach UI if YouTube re-renders the player
  setInterval(() => {
    if (!document.getElementById('yt-dubber-pill') && getPlayerContainer()) {
      boot();
    }
  }, 2500);

})();
