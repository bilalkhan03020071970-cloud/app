// =========================================================
// Universal YouTube AI Dubber — Content Script Engine
// Real-time Any-to-Any Language Translation & Voice Dubbing
// =========================================================

(function () {
  'use strict';

  // Prevent multiple injections
  if (window.__ytUniversalDubberLoaded) return;
  window.__ytUniversalDubberLoaded = true;

  // Default Configuration
  const state = {
    enabled: true,
    sourceLang: 'auto',
    targetLang: 'ur',        // Default: Urdu
    muteOriginal: true,      // 100% mute original video while dubbing
    duckingVolume: 0.0,
    speechRate: 1.0,         // Natural speaking pace
    speechPitch: 1.0,
    showSubtitles: true,
    selectedVoiceURI: '',
    isSpeaking: false,
    minimized: false,
    originalVideoVolume: 1.0,
    originalVideoMuted: false,
    hasCapturedOriginalVolume: false
  };

  // Supported Languages List (Code: Name)
  const LANGUAGES = {
    'ur': 'Urdu (اردو)',
    'en': 'English',
    'hi': 'Hindi (हिन्दी)',
    'ar': 'Arabic (العربية)',
    'es': 'Spanish (Español)',
    'fr': 'French (Français)',
    'de': 'German (Deutsch)',
    'tr': 'Turkish (Türkçe)',
    'ru': 'Russian (Русский)',
    'pt': 'Portuguese (Português)',
    'zh': 'Chinese (中文)',
    'ja': 'Japanese (日本語)',
    'ko': 'Korean (한국어)',
    'it': 'Italian (Italiano)',
    'bn': 'Bengali (বাংলা)',
    'fa': 'Persian (فارسی)'
  };

  // Translation Cache
  const translationCache = new Map();
  const MAX_CACHE_SIZE = 400;

  // State Trackers
  let lastSpokenText = '';
  let pendingTextBuffer = '';
  let debounceTimer = null;
  let captionObserver = null;
  let currentAudio = null;
  let availableVoices = [];

  // =========================================================
  // 1. INITIALIZATION & STORAGE
  // =========================================================
  function loadSettings() {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.sync) {
      chrome.storage.sync.get(null, (stored) => {
        if (stored) {
          // Keep muteOriginal true by default unless explicitly disabled
          Object.assign(state, stored);
          state.muteOriginal = true;
          state.duckingVolume = 0.0;
          updateUIElements();
          enforceMutePolicy();
        }
      });
    }
  }

  function saveSettings() {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.sync) {
      chrome.storage.sync.set(state);
    }
  }

  function initVoices() {
    if (typeof window.speechSynthesis !== 'undefined') {
      availableVoices = window.speechSynthesis.getVoices();
    }
  }
  if (typeof window.speechSynthesis !== 'undefined') {
    initVoices();
    window.speechSynthesis.onvoiceschanged = initVoices;
  }

  // =========================================================
  // 2. VIDEO ELEMENT & AUDIO MUTING POLICY
  // =========================================================
  function getVideoElement() {
    return document.querySelector('video.html5-main-video') || document.querySelector('video');
  }

  function getPlayerContainer() {
    return document.querySelector('#movie_player') || document.querySelector('.html5-video-player');
  }

  // Enforces complete muting of original video when Dubbing is ON,
  // and completely restores original sound when Dubbing is OFF
  function enforceMutePolicy() {
    const video = getVideoElement();
    if (!video) return;

    if (state.enabled) {
      // Capture original volume if not already stored
      if (!state.hasCapturedOriginalVolume) {
        if (video.volume > 0) {
          state.originalVideoVolume = video.volume;
        }
        state.originalVideoMuted = video.muted;
        state.hasCapturedOriginalVolume = true;
      }

      // Completely silence the original video audio
      if (!video.muted || video.volume > 0) {
        video.muted = true;
        video.volume = 0;
      }
    } else {
      // Dubbing is OFF: Restore original video sound
      if (state.hasCapturedOriginalVolume) {
        video.muted = state.originalVideoMuted;
        video.volume = state.originalVideoVolume > 0 ? state.originalVideoVolume : 1.0;
        state.hasCapturedOriginalVolume = false;
      } else {
        video.muted = false;
      }
    }
  }

  // Periodic heartbeat to make sure YouTube doesn't accidentally unmute the video
  setInterval(enforceMutePolicy, 300);

  // =========================================================
  // 3. CAPTIONS OBSERVER & AUTO-ACTIVATION
  // =========================================================
  function ensureCaptionsEnabled() {
    if (!state.enabled) return;

    // 1. Click CC button if not pressed
    const ccBtn = document.querySelector('.ytp-subtitles-button');
    if (ccBtn && ccBtn.getAttribute('aria-pressed') !== 'true') {
      ccBtn.click();
    }

    // 2. Try YouTube internal player API
    const player = getPlayerContainer();
    if (player) {
      try {
        if (typeof player.loadModule === 'function') player.loadModule('captions');
        if (typeof player.toggleSubtitlesOn === 'function') player.toggleSubtitlesOn();
      } catch (_) {}
    }
  }

  // Check every 1.5 seconds to guarantee CC is always active on playing videos
  setInterval(() => {
    if (state.enabled) {
      ensureCaptionsEnabled();
    }
  }, 1500);

  function initCaptionObserver() {
    if (captionObserver) captionObserver.disconnect();

    const handleCaptions = () => {
      if (!state.enabled) return;

      const segments = document.querySelectorAll('.ytp-caption-segment, .caption-visual-line');
      if (!segments || segments.length === 0) return;

      let fullText = Array.from(segments)
        .map(el => el.textContent.trim())
        .filter(t => t.length > 0)
        .join(' ')
        .trim();

      if (!fullText || fullText === lastSpokenText) return;

      // Filter out non-speech sound indicators: [Music], (Applause), etc.
      fullText = fullText.replace(/\[[^\]]+\]|\([^)]+\)/g, '').trim();
      if (!fullText || fullText.length < 2) return;

      pendingTextBuffer = fullText;

      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(() => {
        if (pendingTextBuffer && pendingTextBuffer !== lastSpokenText) {
          const sentence = pendingTextBuffer;
          lastSpokenText = sentence;
          pendingTextBuffer = '';
          processSentence(sentence);
        }
      }, 320); // 320ms pause detects sentence boundary
    };

    captionObserver = new MutationObserver(handleCaptions);

    const targetNode = getPlayerContainer() || document.body;
    captionObserver.observe(targetNode, {
      childList: true,
      subtree: true,
      characterData: true
    });
  }

  // =========================================================
  // 4. TRANSLATION ENGINE (Background Service Worker + Fallback)
  // =========================================================
  async function translateText(text, srcLang, tgtLang) {
    if (!text || text.trim().length === 0) return text;
    if (srcLang === tgtLang) return text;

    const cacheKey = `${srcLang}_${tgtLang}_${text.trim()}`;
    if (translationCache.has(cacheKey)) {
      return translationCache.get(cacheKey);
    }

    return new Promise((resolve) => {
      // Method A: Send to Background Service Worker (Bypasses all CORS/CSP)
      if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
        chrome.runtime.sendMessage({
          action: 'TRANSLATE',
          text: text,
          src: srcLang,
          tgt: tgtLang
        }, (res) => {
          if (chrome.runtime.lastError || !res || !res.success) {
            // Method B: Direct fetch fallback
            directFetchTranslate(text, srcLang, tgtLang).then(resolve);
          } else {
            const result = res.translated || text;
            translationCache.set(cacheKey, result);
            resolve(result);
          }
        });
      } else {
        directFetchTranslate(text, srcLang, tgtLang).then(resolve);
      }
    });
  }

  async function directFetchTranslate(text, srcLang, tgtLang) {
    try {
      const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=${encodeURIComponent(srcLang)}&tl=${encodeURIComponent(tgtLang)}&dt=t&q=${encodeURIComponent(text.trim())}`;
      const res = await fetch(url);
      if (!res.ok) throw new Error('HTTP ' + res.status);
      const data = await res.json();
      if (Array.isArray(data) && Array.isArray(data[0])) {
        return data[0].map(item => item[0]).join('');
      }
    } catch (e) {
      console.warn('[YT AI Dubber] Direct translation fallback notice:', e);
    }
    return text;
  }

  // =========================================================
  // 5. HYBRID SPEECH ENGINE (Natural Audio Stream + TTS Fallback)
  // =========================================================
  async function processSentence(originalSentence) {
    if (!state.enabled || !originalSentence) return;

    const translatedSentence = await translateText(originalSentence, state.sourceLang, state.targetLang);
    showSubtitleBanner(originalSentence, translatedSentence);
    speakSentence(translatedSentence);
  }

  function findBestVoice(langCode) {
    if (!availableVoices || availableVoices.length === 0) {
      initVoices();
    }
    if (state.selectedVoiceURI) {
      const userVoice = availableVoices.find(v => v.voiceURI === state.selectedVoiceURI);
      if (userVoice) return userVoice;
    }

    let match = availableVoices.find(v => v.lang.toLowerCase().startsWith(langCode.toLowerCase()));
    if (!match && langCode === 'ur') {
      match = availableVoices.find(v =>
        v.lang.toLowerCase().includes('ur') ||
        v.name.toLowerCase().includes('urdu') ||
        v.name.toLowerCase().includes('asad')
      );
    }
    if (!match && langCode === 'ur') {
      match = availableVoices.find(v => v.lang.toLowerCase().startsWith('hi'));
    }
    return match || null;
  }

  function speakSentence(text) {
    if (!state.enabled || !text || text.trim().length === 0) return;

    // 1. Cancel previous speaking instance
    if (window.speechSynthesis) window.speechSynthesis.cancel();
    if (currentAudio) {
      currentAudio.pause();
      currentAudio.currentTime = 0;
      currentAudio = null;
    }

    state.isSpeaking = true;
    updateStatusDot('speaking');

    // 2. Play via Natural Google Audio Stream (Fluent, Native Pakistani/Indian Urdu Voice)
    const ttsUrl = `https://translate.google.com/translate_tts?ie=UTF-8&q=${encodeURIComponent(text.trim())}&tl=${state.targetLang}&client=tw-ob`;
    const audio = new Audio(ttsUrl);
    currentAudio = audio;
    audio.playbackRate = state.speechRate;

    audio.onended = () => {
      if (currentAudio === audio) currentAudio = null;
      state.isSpeaking = false;
      updateStatusDot('ready');
      hideSubtitleBanner();
    };

    audio.onerror = () => {
      // 3. Fallback: Web Speech API (speechSynthesis)
      playViaSpeechSynthesis(text);
    };

    audio.play().catch(() => {
      // Fallback if browser audio autoplay blocked
      playViaSpeechSynthesis(text);
    });
  }

  function playViaSpeechSynthesis(text) {
    if (!window.speechSynthesis || !state.enabled) return;

    const utterance = new SpeechSynthesisUtterance(text);
    const voice = findBestVoice(state.targetLang);
    if (voice) {
      utterance.voice = voice;
      utterance.lang = voice.lang;
    } else {
      utterance.lang = state.targetLang;
    }
    utterance.rate = state.speechRate;
    utterance.pitch = state.speechPitch;

    utterance.onend = () => {
      state.isSpeaking = false;
      updateStatusDot('ready');
      hideSubtitleBanner();
    };

    utterance.onerror = () => {
      state.isSpeaking = false;
      updateStatusDot('ready');
      hideSubtitleBanner();
    };

    window.speechSynthesis.speak(utterance);
  }

  // =========================================================
  // 6. VIDEO EVENT LISTENERS
  // =========================================================
  function bindVideoEvents() {
    const video = getVideoElement();
    if (!video || video.__ytDubberBound) return;
    video.__ytDubberBound = true;

    video.addEventListener('play', () => {
      ensureCaptionsEnabled();
      enforceMutePolicy();
    });

    video.addEventListener('pause', () => {
      if (window.speechSynthesis) window.speechSynthesis.cancel();
      if (currentAudio) {
        currentAudio.pause();
        currentAudio = null;
      }
      state.isSpeaking = false;
      updateStatusDot('ready');
      hideSubtitleBanner();
    });

    video.addEventListener('seeking', () => {
      if (window.speechSynthesis) window.speechSynthesis.cancel();
      if (currentAudio) {
        currentAudio.pause();
        currentAudio = null;
      }
      lastSpokenText = '';
      pendingTextBuffer = '';
      state.isSpeaking = false;
      updateStatusDot('ready');
      hideSubtitleBanner();
    });

    video.addEventListener('volumechange', () => {
      enforceMutePolicy();
    });
  }

  // =========================================================
  // 7. IN-PLAYER FLOATING WIDGET UI
  // =========================================================
  function injectPlayerWidget() {
    if (document.getElementById('yt-dubber-pill')) return;

    const player = getPlayerContainer();
    if (!player) return;

    const pill = document.createElement('div');
    pill.id = 'yt-dubber-pill';
    pill.innerHTML = `
      <span class="yt-dubber-mic" id="ytDubMic">🎙️</span>
      <button class="yt-dubber-btn-toggle" id="ytDubToggle" title="Click to Toggle Dubbing ON/OFF (Original Video Muted when ON)">
        <span>Dub</span> <span id="ytDubStatus">ON</span>
      </button>
      <div class="yt-dubber-dot" id="ytDubDot" title="AI Dubber Ready"></div>
      <select class="yt-dubber-select yt-dubber-hide-min" id="ytDubLang">
        ${Object.entries(LANGUAGES).map(([code, name]) =>
          `<option value="${code}" ${code === state.targetLang ? 'selected' : ''}>${name}</option>`
        ).join('')}
      </select>
      <button class="yt-dubber-btn-icon yt-dubber-hide-min" id="ytDubMin" title="Minimize / Expand">─</button>
    `;

    player.appendChild(pill);

    // Live Subtitle Banner inside Player
    const banner = document.createElement('div');
    banner.id = 'yt-dubber-subtitle-banner';
    banner.innerHTML = `<div class="orig" id="ytDubBannerOrig"></div><div class="trans" id="ytDubBannerTrans"></div>`;
    player.appendChild(banner);

    // Pill Toggle Event
    const toggleBtn = document.getElementById('ytDubToggle');
    toggleBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      state.enabled = !state.enabled;

      if (!state.enabled) {
        if (window.speechSynthesis) window.speechSynthesis.cancel();
        if (currentAudio) {
          currentAudio.pause();
          currentAudio = null;
        }
        hideSubtitleBanner();
      } else {
        ensureCaptionsEnabled();
      }

      enforceMutePolicy();
      saveSettings();
      updateUIElements();
    });

    // Language Change Event
    const langSelect = document.getElementById('ytDubLang');
    langSelect.addEventListener('change', (e) => {
      e.stopPropagation();
      state.targetLang = e.target.value;
      if (window.speechSynthesis) window.speechSynthesis.cancel();
      if (currentAudio) {
        currentAudio.pause();
        currentAudio = null;
      }
      saveSettings();
    });

    // Minimize Button
    const minBtn = document.getElementById('ytDubMin');
    minBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      state.minimized = !state.minimized;
      pill.classList.toggle('minimized', state.minimized);
      minBtn.textContent = state.minimized ? '▢' : '─';
    });

    updateUIElements();
  }

  function updateUIElements() {
    const pill = document.getElementById('yt-dubber-pill');
    const mic = document.getElementById('ytDubMic');
    const toggleBtn = document.getElementById('ytDubToggle');
    const statusText = document.getElementById('ytDubStatus');
    const langSelect = document.getElementById('ytDubLang');
    const dot = document.getElementById('ytDubDot');

    if (!pill) return;

    if (state.enabled) {
      toggleBtn.classList.remove('off');
      mic.classList.remove('off');
      statusText.textContent = 'ON';
      dot.className = state.isSpeaking ? 'yt-dubber-dot speaking' : 'yt-dubber-dot';
    } else {
      toggleBtn.classList.add('off');
      mic.classList.add('off');
      statusText.textContent = 'OFF';
      dot.className = 'yt-dubber-dot off';
    }

    if (langSelect) langSelect.value = state.targetLang;
  }

  function updateStatusDot(status) {
    const dot = document.getElementById('ytDubDot');
    if (!dot) return;
    if (!state.enabled) {
      dot.className = 'yt-dubber-dot off';
    } else if (status === 'speaking') {
      dot.className = 'yt-dubber-dot speaking';
    } else {
      dot.className = 'yt-dubber-dot';
    }
  }

  function showSubtitleBanner(original, translated) {
    if (!state.showSubtitles) return;
    const banner = document.getElementById('yt-dubber-subtitle-banner');
    const origEl = document.getElementById('ytDubBannerOrig');
    const transEl = document.getElementById('ytDubBannerTrans');
    if (banner && origEl && transEl) {
      origEl.textContent = original;
      transEl.textContent = translated;
      banner.classList.add('visible');
    }
  }

  function hideSubtitleBanner() {
    const banner = document.getElementById('yt-dubber-subtitle-banner');
    if (banner) banner.classList.remove('visible');
  }

  // =========================================================
  // 8. POPUP COMMUNICATION
  // =========================================================
  if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
    chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
      if (msg.action === 'UPDATE_SETTINGS') {
        Object.assign(state, msg.settings);
        state.muteOriginal = true;
        state.duckingVolume = 0.0;
        updateUIElements();
        if (!state.enabled) {
          if (window.speechSynthesis) window.speechSynthesis.cancel();
          if (currentAudio) {
            currentAudio.pause();
            currentAudio = null;
          }
          hideSubtitleBanner();
        }
        enforceMutePolicy();
        sendResponse({ success: true });
      } else if (msg.action === 'GET_STATE') {
        sendResponse({
          state: state,
          voices: availableVoices.map(v => ({ name: v.name, lang: v.lang, uri: v.voiceURI }))
        });
      }
      return true;
    });
  }

  // =========================================================
  // 9. BOOTSTRAP & NAVIGATION WATCHER
  // =========================================================
  function boot() {
    loadSettings();
    injectPlayerWidget();
    bindVideoEvents();
    initCaptionObserver();
    ensureCaptionsEnabled();
    enforceMutePolicy();
  }

  boot();

  window.addEventListener('yt-navigate-finish', () => {
    setTimeout(boot, 600);
  });
  window.addEventListener('load', boot);

  // Periodic heartbeat to keep UI attached and audio muted
  setInterval(() => {
    if (!document.getElementById('yt-dubber-pill') && getPlayerContainer()) {
      boot();
    }
  }, 2000);

})();
