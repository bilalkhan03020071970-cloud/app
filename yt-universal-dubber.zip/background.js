// =========================================================
// Universal YouTube AI Dubber — Background Service Worker
// Manages Offscreen Audio & Translation Routing
// =========================================================

chrome.runtime.onInstalled.addListener(() => {
  console.log('[YT AI Dubber BG] Extension installed and ready.');
});

// Translation Cache
const bgTransCache = new Map();
const MAX_CACHE = 500;

let creatingOffscreenPromise = null;

async function ensureOffscreenDocument() {
  if (await chrome.offscreen.hasDocument()) {
    return;
  }
  if (creatingOffscreenPromise) {
    await creatingOffscreenPromise;
    return;
  }
  creatingOffscreenPromise = chrome.offscreen.createDocument({
    url: 'offscreen.html',
    reasons: ['AUDIO_PLAYBACK'],
    justification: 'Real-time multi-language voice dubbing playback'
  });
  await creatingOffscreenPromise;
  creatingOffscreenPromise = null;
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'TRANSLATE') {
    const { text, src = 'auto', tgt = 'ur' } = request;
    if (!text || text.trim().length === 0) {
      sendResponse({ success: true, translated: '' });
      return false;
    }

    const cacheKey = `${src}_${tgt}_${text.trim()}`;
    if (bgTransCache.has(cacheKey)) {
      sendResponse({ success: true, translated: bgTransCache.get(cacheKey) });
      return false;
    }

    const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=${encodeURIComponent(src)}&tl=${encodeURIComponent(tgt)}&dt=t&q=${encodeURIComponent(text.trim())}`;
    fetch(url)
      .then(res => res.json())
      .then(data => {
        let translated = '';
        if (Array.isArray(data) && Array.isArray(data[0])) {
          translated = data[0].map(item => item[0]).join('');
        }
        if (translated) {
          if (bgTransCache.size > MAX_CACHE) {
            const firstKey = bgTransCache.keys().next().value;
            bgTransCache.delete(firstKey);
          }
          bgTransCache.set(cacheKey, translated);
          sendResponse({ success: true, translated });
        } else {
          sendResponse({ success: false, translated: text });
        }
      })
      .catch(err => {
        sendResponse({ success: false, translated: text, error: err.message });
      });

    return true; // async
  } else if (request.action === 'PLAY_AUDIO') {
    ensureOffscreenDocument()
      .then(() => {
        chrome.runtime.sendMessage({
          target: 'offscreen',
          action: 'PLAY_AUDIO',
          text: request.text,
          lang: request.lang,
          rate: request.rate
        }, (res) => {
          sendResponse(res || { success: true });
        });
      })
      .catch(err => {
        console.warn('[YT Dubber BG] Offscreen creation error:', err);
        sendResponse({ success: false, error: err.message });
      });
    return true;
  } else if (request.action === 'STOP_AUDIO') {
    ensureOffscreenDocument()
      .then(() => {
        chrome.runtime.sendMessage({
          target: 'offscreen',
          action: 'STOP_AUDIO'
        }).catch(() => {});
        sendResponse({ success: true });
      })
      .catch(() => {
        sendResponse({ success: true });
      });
    return true;
  }
});
