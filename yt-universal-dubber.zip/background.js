// =========================================================
// Universal YouTube AI Dubber — Background Service Worker
// Handles Translation & TTS Requests without Page CORS/CSP
// =========================================================

const bgCache = new Map();
const MAX_CACHE = 500;

chrome.runtime.onInstalled.addListener(() => {
  console.log('[YT AI Dubber] Background service worker ready.');
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'TRANSLATE') {
    const { text, src = 'auto', tgt = 'ur' } = request;
    if (!text || text.trim().length === 0) {
      sendResponse({ success: true, translated: '' });
      return false;
    }

    const cacheKey = `${src}_${tgt}_${text.trim()}`;
    if (bgCache.has(cacheKey)) {
      sendResponse({ success: true, translated: bgCache.get(cacheKey) });
      return false;
    }

    const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=${encodeURIComponent(src)}&tl=${encodeURIComponent(tgt)}&dt=t&q=${encodeURIComponent(text.trim())}`;

    fetch(url)
      .then(res => {
        if (!res.ok) throw new Error('HTTP ' + res.status);
        return res.json();
      })
      .then(data => {
        let translated = '';
        if (Array.isArray(data) && Array.isArray(data[0])) {
          translated = data[0].map(item => item[0]).join('');
        }
        if (translated) {
          if (bgCache.size > MAX_CACHE) {
            const firstKey = bgCache.keys().next().value;
            bgCache.delete(firstKey);
          }
          bgCache.set(cacheKey, translated);
          sendResponse({ success: true, translated: translated });
        } else {
          sendResponse({ success: false, translated: text });
        }
      })
      .catch(err => {
        console.warn('[YT AI Dubber BG] Translation failed:', err);
        sendResponse({ success: false, error: err.message, translated: text });
      });

    return true; // Keep message channel open for async response
  }
});
